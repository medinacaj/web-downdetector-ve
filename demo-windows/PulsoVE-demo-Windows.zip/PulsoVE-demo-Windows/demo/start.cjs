// Exclusivo de la demo local. Nunca utiliza una DB proporcionada desde el host.
const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert/strict');
const {spawnSync,spawn}=require('child_process');const postgres=require('postgres');
(async()=>{
 const url=new URL(process.env.DATABASE_URL);assert.ok(url.hostname==='db'&&url.pathname==='/pulsove_demo');
 const store=path.join('/app/.demo-data','settings.json');let privateSettings;
 if(fs.existsSync(store))privateSettings=JSON.parse(fs.readFileSync(store,'utf8'));
 else{privateSettings={JWT_SECRET:crypto.randomBytes(32).toString('hex'),ANONYMIZATION_SALT:crypto.randomBytes(32).toString('hex')};fs.writeFileSync(store,JSON.stringify(privateSettings),{mode:0o600});}
 const env={...process.env,...privateSettings,REDIS_URL:'',ENABLE_TURNSTILE:'false',ENABLE_TECHNICAL_CHECKS:'false',PUBLIC_INDEXABLE:'false',SITE_URL:'',TRUSTED_CLIENT_IP_HEADER:'',NEXT_TELEMETRY_DISABLED:'1'};
 const run=(script,args=[])=>{const r=spawnSync(process.execPath,['node_modules/tsx/dist/cli.mjs',script,...args],{env,stdio:'inherit',timeout:120000});assert.equal(r.status,0,'No se completo '+script);};
 const migrate=spawnSync(process.execPath,['node_modules/drizzle-kit/bin.cjs','migrate'],{env,stdio:'inherit',timeout:120000});assert.equal(migrate.status,0);
 run('scripts/seed.ts');
 const db=postgres(env.DATABASE_URL,{max:1,onnotice:()=>{}});
 try{
  const existing=await db`select id from services where slug='motor-test-service'`;
  const fixtureMarker=path.join('/app/.demo-data','fixtures-ready.json');
  let ready=false;try{ready=JSON.parse(fs.readFileSync(fixtureMarker,'utf8')).version===1;}catch{}
  if(!ready||!existing.length){
   // Recuperar solo la fixture propia si el primer inicio se interrumpio.
   if(existing.length)await db`delete from services where slug='motor-test-service'`;
   run('scripts/dev-synthetic-traffic.ts');
   await db`update reports set created_at=created_at-interval '1 hour' where service_id=(select id from services where slug='motor-test-service')`;
   const latest=(await db`select date_trunc('hour',max(created_at)) as hour from reports`)[0].hour;
   for(const minute of [15,30,45]){const at=new Date(latest);at.setUTCMinutes(minute,0,0);run('scripts/aggregate-cron.ts',['--at='+at.toISOString()]);}
   fs.writeFileSync(fixtureMarker+'.tmp',JSON.stringify({version:1,completedAt:new Date().toISOString()}),{mode:0o600});
   fs.renameSync(fixtureMarker+'.tmp',fixtureMarker);
  }
 }finally{await db.end();}
 console.log('PulsoVE: demo local con datos ficticios. Abre http://localhost:3080');
 const child=spawn(process.execPath,['node_modules/next/dist/bin/next','dev','--hostname','0.0.0.0','--port','3000'],{env,stdio:'inherit'});
 for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>child.kill(signal));
 child.on('exit',code=>{process.exitCode=code||0;});
})().catch(()=>{console.error('No se pudo iniciar la demo. Revisar los logs locales de Docker.');process.exitCode=1;});
