import { and, asc, eq, ilike, sql } from 'drizzle-orm';
import { db } from '@/lib/db/client';
import { services, categories, reports, incidents } from '@/lib/db/schema';
import { statusesForServices } from './status';
import type { OperationalStatus } from '@/lib/engine/status-bands';

export type DirectorySort = 'activity' | 'alphabetical' | 'stability';

export interface DirectoryService {
  slug: string;
  name: string;
  description: string | null;
  categorySlug: string;
  categoryName: string;
  reportsLast24h: number;
  incidentsAllTime: number;
  status: OperationalStatus;
}

export async function getCategories() {
  return db.select({ slug: categories.slug, name: categories.name }).from(categories).orderBy(asc(categories.sortOrder));
}

export async function getDirectoryServices(params: {
  q?: string;
  category?: string;
  status?: OperationalStatus;
  sort?: DirectorySort;
}): Promise<{ services: DirectoryService[]; total: number }> {
  const since24h = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();

  const conditions = [eq(services.active, true)];
  if (params.q) conditions.push(ilike(services.name, `%${params.q}%`));
  if (params.category) conditions.push(eq(categories.slug, params.category));

  const rows = await db
    .select({
      id: services.id,
      slug: services.slug,
      name: services.name,
      description: services.description,
      categorySlug: categories.slug,
      categoryName: categories.name,
      reportsLast24h: sql<number>`count(distinct ${reports.id}) filter (where ${reports.createdAt} >= ${since24h})::int`,
      incidentsAllTime: sql<number>`count(distinct ${incidents.id})::int`,
    })
    .from(services)
    .innerJoin(categories, eq(categories.id, services.categoryId))
    .leftJoin(reports, eq(reports.serviceId, services.id))
    .leftJoin(incidents, eq(incidents.serviceId, services.id))
    .where(and(...conditions))
    .groupBy(services.id, categories.slug, categories.name)
    .orderBy(asc(services.name));

  const statuses = await statusesForServices(rows.map(row => row.id));
  let withStatus: DirectoryService[] = rows.map(({ id, ...rest }) => ({
    ...rest, status: statuses.get(id) ?? 'insufficient_data',
  }));

  if (params.status) {
    withStatus = withStatus.filter((s) => s.status === params.status);
  }

  const sort = params.sort ?? 'alphabetical';
  if (sort === 'activity') {
    withStatus.sort((a, b) => b.reportsLast24h - a.reportsLast24h);
  } else if (sort === 'stability') {
    withStatus.sort((a, b) => a.incidentsAllTime - b.incidentsAllTime || a.name.localeCompare(b.name));
  } else {
    withStatus.sort((a, b) => a.name.localeCompare(b.name));
  }

  return { services: withStatus, total: withStatus.length };
}
