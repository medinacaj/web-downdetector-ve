PulsoVE - Demo local para Windows

1. Extrae todo el ZIP.
2. Abre LEEME.html para ver el video y las instrucciones.
3. Abre Docker Desktop con contenedores Linux.
4. Haz doble clic en INICIAR-DEMO.cmd.
5. Se abrira http://localhost:3080.

Primera vez: necesita Internet y varios minutos para descargar dependencias.
No necesitas hosting ni dominio.
DETENER-DEMO.cmd detiene la demo sin borrar los datos.
Solo datos ficticios. No publiques esta configuracion.

Verificado: aplicacion y PostgreSQL en contenedores Linux, envio real y reinicio.
Archivos CMD revisados; ejecucion nativa en Windows no verificada aqui.
Detalle de pruebas: VALIDACION.json.
