@echo off
setlocal
cd /d "%~dp0"
set DOCKER_HOST=
set DOCKER_CONTEXT=
set DOCKER_TLS=
set DOCKER_TLS_VERIFY=
set DOCKER_CERT_PATH=
set "DEMO_ENGINE=npipe:////./pipe/dockerDesktopLinuxEngine"
docker --host "%DEMO_ENGINE%" info >nul 2>&1
if not errorlevel 1 goto detener
set "DEMO_ENGINE=npipe:////./pipe/docker_engine"
:detener
docker --host "%DEMO_ENGINE%" compose -p pulsove-evaluacion -f compose.demo.yml stop
echo Se conservan los datos de demostracion.
pause
