<!-- BEGIN:nextjs-agent-rules -->

# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` (resolved from this file's directory; in monorepos the `next` package may not be visible from the repo root) before writing any code. Heed deprecation notices.

This block is written and re-added by `next dev` — verify at `node_modules/next/dist/server/lib/generate-agent-files.js`. Removing it from a diff only re-creates the uncommitted change; committing it with your work keeps the tree clean.

<!-- END:nextjs-agent-rules -->

## Criterios jurídico-tecnológicos transversales
Al diseñar, corregir, auditar o publicar, leer `docs/ASESOR_LEGAL_TECNOLOGICO.md`. Aplicar sus siete capas cuando sean relevantes (legal, técnica, seguridad, datos, evidencia, responsabilidad y negocio), documentar jurisdicción, licencias y datos, y separar hechos de hipótesis. No afirmar cumplimiento legal ni autorizaciones sin evidencia. Estas pautas complementan, sin sustituir, las pruebas técnicas y el criterio profesional habilitado.

## Colaboración Claude + ChatGPT/Codex mediante GitHub
Para cambios, auditorías, Pull Requests y transferencias entre agentes, aplicar `docs/agent-workflow.md`. Recuperar el Issue, diff, SHA y resultados de pruebas antes de pedir contexto adicional. No asumir que la rama predeterminada se llama `main`. Mantener estas reglas específicas del proyecto y las exigencias jurídico-tecnológicas aplicables; el protocolo compartido no las reemplaza.

## Controles verificables del proyecto
Aplicar `docs/ESTANDARES-Y-CONTROLES.md` al cambiar código o datos y `docs/OPERACION-ITIL.md` al preparar cambios operativos. Ejecutar `npm run check:standards` y las pruebas pertinentes. Mantener el diccionario con `npm run docs:data` cuando cambie el esquema; no reescribir migraciones históricas ni sus checksums para hacer pasar controles. Registrar excepciones y verificaciones no ejecutadas. No afirmar certificación ITIL/ISO ni conformidad integral a partir de lint, plantillas o pruebas locales.

Aplicar además el estándar entregado por el usuario en `docs/ESTANDAR-WEB-INTEGRAL.md`, según contexto y riesgo; consultar `docs/APLICACION-ESTANDAR-WEB.md` para alcance, evidencia y pendientes. No introducir servicios o tecnologías sin utilidad demostrada ni afirmar métricas, auditorías o despliegues que no se ejecutaron.
