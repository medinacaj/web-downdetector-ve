@echo off
setlocal
cd /d "%~dp0"
where docker >nul 2>&1
if errorlevel 1 goto sinDocker
set DOCKER_HOST=
set DOCKER_CONTEXT=
set DOCKER_TLS=
set DOCKER_TLS_VERIFY=
set DOCKER_CERT_PATH=
set "DEMO_ENGINE=npipe:////./pipe/dockerDesktopLinuxEngine"
docker --host "%DEMO_ENGINE%" info >nul 2>&1
if not errorlevel 1 goto motorListo
set "DEMO_ENGINE=npipe:////./pipe/docker_engine"
docker --host "%DEMO_ENGINE%" info >nul 2>&1
if errorlevel 1 goto sinMotor
:motorListo
if exist ".env" goto configurado
powershell -NoProfile -Command "$bytes=New-Object byte[] 32; $rng=[Security.Cryptography.RandomNumberGenerator]::Create(); $rng.GetBytes($bytes); $rng.Dispose(); $password=[BitConverter]::ToString($bytes).Replace('-','').ToLowerInvariant(); [IO.File]::WriteAllText((Join-Path (Get-Location) '.env'), ('DEMO_DATABASE_PASSWORD='+$password+[Environment]::NewLine), [Text.Encoding]::ASCII)"
if errorlevel 1 goto fallo
:configurado
echo Preparando PulsoVE. La primera vez necesita Internet y puede tardar varios minutos.
docker --host "%DEMO_ENGINE%" compose -p pulsove-evaluacion -f compose.demo.yml up --build -d
if errorlevel 1 goto fallo
powershell -NoProfile -Command "$ready=$false; for($attempt=0;$attempt -lt 120;$attempt++){try{$response=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:3080/api/health' -TimeoutSec 3;if($response.StatusCode -eq 200){$ready=$true;break}}catch{};Start-Sleep -Seconds 1};if(-not $ready){exit 1}"
if errorlevel 1 goto fallo
start "" "http://localhost:3080"
echo Demo iniciada. Puedes cerrar esta ventana. Usa DETENER-DEMO.cmd para detenerla.
pause
exit /b 0
:sinDocker
echo Instala Docker Desktop para Windows y vuelve a abrir este archivo.
echo Instrucciones oficiales: https://docs.docker.com/desktop/setup/install/windows-install/
pause
exit /b 1
:sinMotor
echo Abre Docker Desktop con contenedores Linux y vuelve a intentarlo.
pause
exit /b 1
:fallo
echo No se pudo completar el inicio. Revisa Docker Desktop y que el puerto 3080 este libre.
echo Los datos existentes no se han borrado.
pause
exit /b 1
